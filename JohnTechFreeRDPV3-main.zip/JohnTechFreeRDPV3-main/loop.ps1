$i = 360
do {
    Write-Host $i
    Sleep 60
    $i--
} while ($i -gt 0)
