# FREE RDP WINDOWS SERVER!

Create Free RDP 7GB RAM and 2 CPU Core with Github.
Follow these instructions

+ Click Fork to get started (Mobile users please activate Desktop Mode).
+ Visit https://dashboard.ngrok.com to get NGROK_AUTH_TOKEN
+ In this repository go to Settings> Secrets> New repository secret
+ Name: NGROK_AUTH_TOKEN
+ Value: https://dashboard.ngrok.com/auth/your-authtoken copy and paste authtoken in the value
+ Click add secret
+ Go to Action (if you see any watning click "I understand...") > FreeRDP > run workflow
+ Refresh website - go to FreeRDP > build
+ Click the down arrow "RDP INFO LOGIN" To get IP, User, Password.
